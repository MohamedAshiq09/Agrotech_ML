__version__ = "1.0.2"
__author__ = "AgroGraphNet Team"
__email__ = "contact@agrographnet.com"
__description__ = "Graph Neural Networks for Agricultural Disease Prediction"